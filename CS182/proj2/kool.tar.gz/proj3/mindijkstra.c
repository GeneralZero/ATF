//dijkstra.c

#include "mygraph.h"

int *dijkstra(t_graph *g, int k){
	int i,count,newmin,oldmin;
	int* ret = (int*)malloc(sizeof(int)*g->maxv);
	t_edge* temp = (t_edge*)malloc(sizeof(t_edge));
	t_heap* theHeap = newHeap(g->maxv);
	for(i=0;i<g->maxv;i++)
		g->vertices[i].visited = FALSE;
	g->vertices[k].visited = TRUE;
	for(i=0;i<g->maxv;i++){
		ret[i] = g->am[k][i];
		if(g->am[k][i]!=0){
			//printf("%d",g->am[k][i]);
			addMinElement(theHeap,(void*)new_edge(k,i,g->am[k][i]),&eecomp);
		}
	}
	while(theHeap->current_size>0){
		temp = (t_edge*)popMinHeap(theHeap,&eecomp);
		g->vertices[temp->dst].visited = TRUE;
		for(i=0;i<(g->maxv);i++){
			if(g->am[temp->dst][i]!=0&&g->vertices[i].visited ==FALSE){
				addMinElement(theHeap,(void*)new_edge(temp->dst,i,g->am[temp->dst][i]),&eecomp);
				if(ret[i]>ret[temp->dst]+g->am[temp->dst][i]||(ret[i]==0&&ret[temp->dst]!=0)){
					ret[i]=ret[temp->dst]+g->am[temp->dst][i];
				}
			}
		}
	}
	return ret;	
}
